/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package design.pattern.finals;

class Mediator {
    private List<Communication> communications = new ArrayList<>();

    public void registerCommunication(Communication communication) {
        communications.add(communication);
    }

    public void notifyCommunications() {
        for (Communication communication : communications) {
            communication.receiveMessage("Broadcast message");
        }
    }
}