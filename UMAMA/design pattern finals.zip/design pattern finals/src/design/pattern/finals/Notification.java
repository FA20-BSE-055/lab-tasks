/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package design.pattern.finals;

class Notification implements Communication {
    private Mediator mediator;

    public Notification(Mediator mediator) {
        this.mediator = mediator;
    }

    public void requestFeedback() {
        // Request feedback logic
    }

    public void sendNotification() {
        // Send notification logic
        mediator.registerCommunication(this);
    }

    @Override
    public void receiveMessage(String message) {
        // Implementation for handling notifications
    }
}