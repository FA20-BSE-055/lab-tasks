/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package design.pattern.finals;

// Facade for easy interface

import javax.management.Notification;

class ExamSystemFacade {
    private Mediator mediator;

    public ExamSystemFacade(Mediator mediator) {
        this.mediator = mediator;
    }

    // Other methods for exam scheduling, progress monitoring, etc.

    public void sendNotification(Notification notification) {
        mediator.registerCommunication((Communication) notification);
    }
}