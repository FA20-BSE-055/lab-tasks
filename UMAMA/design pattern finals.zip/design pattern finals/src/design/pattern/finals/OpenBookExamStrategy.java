/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package design.pattern.finals;

class OpenBookExamStrategy implements ExamConductionStrategy {
    @Override
    public void conductExam() {
        // Implementation for an open-book exam
    }
}