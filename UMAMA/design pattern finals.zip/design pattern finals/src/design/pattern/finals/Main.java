/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package design.pattern.finals;

public class Main {
    public static void main(String[] args) {
        // Initialize components
        Settings settings = Settings.getInstance();
        Mediator mediator = new Mediator();
        ExamSystemFacade examSystemFacade = new ExamSystemFacade(mediator);
        CaseManagement caseManagement = new CaseManagement(mediator);

        // Create and use objects
        Notification notification = new Notification(mediator);
        notification.requestFeedback();
        notification.sendNotification();

        // Handle case triggering notifications
        caseManagement.handleCase();
    }
}