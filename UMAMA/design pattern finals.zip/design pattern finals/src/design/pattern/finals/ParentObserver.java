/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package design.pattern.finals;

class ParentObserver implements Observer {
    // Implementation for updating parent on child's progress
    @Override
    public void update() {
        // Update logic
    }
}
